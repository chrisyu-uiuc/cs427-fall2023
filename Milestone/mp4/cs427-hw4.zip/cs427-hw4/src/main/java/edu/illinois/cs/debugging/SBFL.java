package edu.illinois.cs.debugging;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.parser.Parser;
import org.jsoup.select.Elements;

import java.lang.Math;
import  java.util.stream.Collectors;
import java.util.ArrayList;
import java.util.Map.*;
/**
 * Implementation for Spectrum-based Fault Localization (SBFL).
 *
 */
public class SBFL
{

	/**
	 * Use Jsoup to parse the coverage file in the XML format.
	 *
	 * @param file
	 * @return a map from each test to the set of lines that it covers
	 * @throws FileNotFoundException
	 * @throws IOException
	 */
	protected static Map<String, Set<String>> readXMLCov(File file)
			throws FileNotFoundException, IOException {
		FileInputStream fileInputStream = new FileInputStream(file);

		Map<String, Set<String>> res = new HashMap<String, Set<String>>();
		Document document = Jsoup.parse(fileInputStream, "UTF-8", "", Parser.xmlParser());

		Elements tests = document.select("test");
		for (Element test : tests) {
			Element name = test.child(0);
			Element covLines = test.child(1);

			Set<String> lines = new HashSet<String>();
			String[] items = covLines.text().split(", ");
			Collections.addAll(lines, items);
			res.put(name.text(), lines);
		}
		return res;
	}

	/**
	 * Compute the suspiciousness values for all covered statements based on
	 * Ochiai
	 *
	 * @param cov
	 * @param failedTests
	 * @return a map from each line to its suspiciousness value
	 */
	public static Map<String, Double> Ochiai(Map<String, Set<String>> cov, Set<String> failedTests) {

		Map<String, Double> susp = new LinkedHashMap<String, Double>();

		Set<String> allStatements = new HashSet<String>();
		Set<String> successTests = new HashSet<String>();

		for (Map.Entry<String, Set<String>> entry : cov.entrySet()) {
			String testName = entry.getKey();
			Set<String> value = entry.getValue();

			for (String v : value) {
				allStatements.add(v);
			}
		}

		for (String statement : allStatements) {
			int failedTestCount = 0;
			int successTestCount = 0;
			for (Map.Entry<String, Set<String>> entry : cov.entrySet()) {
				String testName = entry.getKey();
				Set<String> value = entry.getValue();
				if(value.contains(statement)) {
					if(failedTests.contains(testName)) {
						failedTestCount++;
					} else {
						successTestCount++;
					}
				}
			}

			susp.put(statement, ((double)failedTestCount / Math.sqrt(failedTests.size() * (failedTestCount + successTestCount) )) );
		}
		return susp;
	}

	/**
	 * Get the suspiciousness value for the buggy line from the suspicious
	 * statement list
	 *
	 * @param susp
	 * @param buggyLine
	 * @return the suspiciousness value for the buggy line
	 */
	protected static double getSusp(Map<String, Double> susp,String buggyLine) {
		// TODO
		return susp.get(buggyLine);
	}

	/**
	 * Rank all statements based on the descending order of their suspiciousness
	 * values. Get the rank (print the lowest rank for the tied cases) for the
	 * buggy line from the suspicious statement list
	 *
	 * @param susp
	 * @param buggyLine
	 * @return the rank of the buggy line
	 */
	protected static int getRank(Map<String, Double> susp, String buggyLine) {
		//List<Map.Entry<String, Double>> list = new LinkedList<Map.Entry<String, Double>>(susp.entrySet());
		//List<Entry<Integer, Integer>> nlist = new ArrayList<>(map.entrySet());
		//list.sort(Entry.comparingByValue(Comparator.reverseOrder());
		Map<Double, Set<String>> result = new HashMap<Double, Set<String>>();

		for (Map.Entry<String, Double> entry : susp.entrySet()) {
			String statement = entry.getKey();
			Double doubleValue = entry.getValue();
			if(result.get(doubleValue) == null) {
				Set<String> data = new   HashSet<String>();
				data.add(statement);
				result.put(doubleValue,data);
			} else {
				Set<String> data = result.get(doubleValue);//new new HashSet<String>();
				data.add(statement);
				result.put(doubleValue,data);
			}
		}

		Map<Double, Set<String>> sortedTreeMap = new TreeMap<>(Comparator.reverseOrder());
		sortedTreeMap.putAll(result);
		int pos = 0;

		for (Map.Entry<Double, Set<String>> entry : sortedTreeMap.entrySet()) {
			Set<String> setString = entry.getValue();

			pos += setString.size();
			if(setString.contains(buggyLine)) {
				break;
			}
		}
		return pos;
	}

}
